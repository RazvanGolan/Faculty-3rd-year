#pragma once

#include "lexer.h"

void parse(Token *tokens);
