#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include "parser.h"

Token *iTk;		// the iterator in the tokens list
Token *consumedTk;		// the last consumed token

void tkerr(const char *fmt,...)
{
	fprintf(stderr,"error in line %d: ",iTk->line);
	va_list va;
	va_start(va,fmt);
	vfprintf(stderr,fmt,va);
	va_end(va);
	fprintf(stderr,"\n");
	exit(EXIT_FAILURE);
}

bool consume(int code)
{
	if(iTk->code==code){
		consumedTk=iTk;
		iTk=iTk->next;
		return true;
		}
	return false;
}

// typeBase: TYPE_INT | TYPE_DOUBLE | TYPE_CHAR | STRUCT ID
bool typeBase()
{
	if(consume(TYPE_INT))
  	{
		return true;
	}
	if(consume(TYPE_DOUBLE))
    {
		return true;
	}
	if(consume(TYPE_CHAR))
    {
		return true;
	}
	if(consume(STRUCT))
    {
		if(consume(ID))
        {
			return true;
		}
	}
	return false;
}

// unit: ( structDef | fnDef | varDef )* END
bool unit()
{
	for(;;){
//		if(structDef()){}
//		else if(fnDef()){}
//		else if(varDef()){}
//		else break;
		}
	if(consume(END)){
		return true;
		}
	return false;
	}

// include error handling as well
void parse(Token *tokens){
	iTk=tokens;
	if(!unit())tkerr("syntax error");
	}
